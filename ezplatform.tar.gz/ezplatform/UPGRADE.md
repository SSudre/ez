# Upgrade instructions

Please visit our online documentation for instructions:
https://doc.ez.no/display/DEVELOPER/Updating+eZ+Platform

For legacy upgrade procedures, please go to our legacy documentation:
* Go to https://doc.ez.no/display/MAIN
* Click on the version you have
* Go to "Installation and Upgrade Guides"
* Select "Upgrade"

For instance for 5.2 upgrade go to:
https://doc.ez.no/display/EZP52/Upgrade
